
weather = raw_input("What is the weather? (cold, raining, etc.): ")

if weather == "cold":
    print("Wear a sweater!")
elif weather == "raining":
    print("Bring an umbrella")
else:
    print("Dress normally :)")
