
# Remember, we get a string from raw_input, but we need an int to compare it
weather = int(raw_input("What temperature is it now? (as a number, please): "))

# if the weather is greater than or equal to 25 degrees
if "replace this with the right condition":
    print("Go to the beach!")
# the weather is less than 25 degrees AND greater than 15 degrees
elif "replace this with the right conditions":
    # Still warm enough for ice cream!
else:
    # Wear a sweater and dream of beaches.
