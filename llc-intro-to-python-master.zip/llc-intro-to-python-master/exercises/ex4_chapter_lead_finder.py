# Import the csv library
import csv

# Open the 'llc-chapters.csv' file

# Convert it to a csv_data structure

# Loop through each of the rows

    # Compare the 'City' in the row with your city

        # Print a thank you message to your chapter lead(s)
