# -*- coding: utf-8 -*-
#  Importez le module csv
import csv

# Ouvrez le fichier '../llc-chapters.csv'

# Convertissez-le en une structure de données csv

# bouclez dans chacune des lignes

    # comparez le champ 'City' à votre ville

        # Imprimez un message qui remerci les responsables du chapitre dans la console
